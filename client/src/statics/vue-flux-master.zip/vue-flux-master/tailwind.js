module.exports = {
  theme: {
    extend: {}
  },
  variants: {},
  plugins: []
}
